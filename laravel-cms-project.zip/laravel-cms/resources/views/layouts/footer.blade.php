{{-- COURSE: Blade @include partial - footer --}}
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-3">
                <h5 class="fw-bold"><i class="fas fa-code me-2"></i>Laravel CMS</h5>
                <p class="text-muted small">A full CMS project built as part of the "PHP with Laravel for Beginners" course by Edwin Diaz.</p>
            </div>
            <div class="col-md-4 mb-3">
                <h6 class="fw-bold">Course Topics Covered</h6>
                <ul class="list-unstyled text-muted small">
                    <li>✅ Routes & Named Routes</li>
                    <li>✅ Controllers & Resource Controllers</li>
                    <li>✅ Blade Templating Engine</li>
                    <li>✅ Eloquent ORM & Relationships</li>
                    <li>✅ Migrations & Seeders</li>
                    <li>✅ Authentication & Middleware</li>
                    <li>✅ File Uploads & Storage</li>
                    <li>✅ CRUD & Validation</li>
                </ul>
            </div>
            <div class="col-md-4 mb-3">
                <h6 class="fw-bold">Quick Links</h6>
                <ul class="list-unstyled">
                    <li><a href="{{ route('posts.index') }}" class="text-muted text-decoration-none">Blog</a></li>
                    <li><a href="{{ route('categories.index') }}" class="text-muted text-decoration-none">Categories</a></li>
                    <li><a href="{{ route('login') }}" class="text-muted text-decoration-none">Login</a></li>
                </ul>
            </div>
        </div>
        <hr class="border-secondary">
        <p class="text-center text-muted small mb-0">
            &copy; {{ date('Y') }} Laravel CMS · Built with ❤️ using Laravel
        </p>
    </div>
</footer>
