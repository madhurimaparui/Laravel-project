<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;

/**
 * AdminMiddleware
 *
 * COURSE SECTION COVERED: Middleware
 * - Protecting routes so only admin users can access the admin panel
 * - Registered in app/Http/Kernel.php as 'admin'
 */
class AdminMiddleware
{
    /**
     * Handle an incoming request.
     * If user is not admin → redirect back with error message.
     */
    public function handle(Request $request, Closure $next)
    {
        if (!auth()->check() || !auth()->user()->isAdmin()) {
            return redirect()->route('home')
                ->with('error', 'Access denied. Admins only.');
        }

        return $next($request);
    }
}
