<?php

namespace App\Http\Controllers;

use App\Models\Tag;

/**
 * TagController
 * COURSE: Many-to-many relationships (belongsToMany)
 */
class TagController extends Controller
{
    public function show($slug)
    {
        $tag = Tag::where('slug', $slug)->firstOrFail();
        $posts = $tag->posts()->with(['category', 'user'])->published()->paginate(6);
        return view('tags.show', compact('tag', 'posts'));
    }
}
