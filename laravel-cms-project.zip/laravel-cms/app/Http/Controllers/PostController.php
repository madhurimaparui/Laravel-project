<?php

namespace App\Http\Controllers;

use App\Models\Post;
use App\Models\Category;
use Illuminate\Http\Request;

/**
 * PostController (Public)
 *
 * COURSE SECTIONS COVERED:
 * - Laravel Fundamentals: Controllers (creating, routing, resource)
 * - Laravel Fundamentals: Views (passing data)
 * - Database: Eloquent / ORM (reading data, scopes, relationships)
 * - Pagination
 */
class PostController extends Controller
{
    /**
     * Show list of all published posts.
     * COURSE: Reading data with Eloquent, pagination, passing data to views
     */
    public function index(Request $request)
    {
        // Eloquent query with scope, eager loading (relationships), and pagination
        $posts = Post::with(['category', 'user', 'tags'])
                     ->published()
                     ->latest()
                     ->paginate(6);

        $categories = Category::withCount('posts')->get();

        // COURSE: Passing data to views using compact()
        return view('posts.index', compact('posts', 'categories'));
    }

    /**
     * Show a single post.
     * COURSE: Route model binding, show related data via relationships
     */
    public function show($slug)
    {
        // COURSE: Reading with constraints (where)
        $post = Post::with(['category', 'user', 'tags', 'comments.user'])
                    ->where('slug', $slug)
                    ->where('is_published', true)
                    ->firstOrFail();

        // Related posts (same category)
        $related = Post::with('category')
                       ->published()
                       ->where('category_id', $post->category_id)
                       ->where('id', '!=', $post->id)
                       ->limit(3)
                       ->get();

        return view('posts.show', compact('post', 'related'));
    }
}
