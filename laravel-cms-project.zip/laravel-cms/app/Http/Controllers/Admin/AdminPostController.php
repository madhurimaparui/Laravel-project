<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Category;
use App\Models\Tag;
use Illuminate\Http\Request;
use Illuminate\Support\Str;

/**
 * Admin PostController
 *
 * COURSE SECTIONS COVERED:
 * - CRUD with Eloquent (Create, Read, Update, Delete)
 * - Forms & Validation (Request validation, error messages)
 * - File Management (image upload, Storage facade)
 * - Flash Messages (session flash)
 * - Resource Controllers (RESTful: index, create, store, show, edit, update, destroy)
 * - Eloquent Relationships (sync tags - many-to-many)
 */
class AdminPostController extends Controller
{
    /**
     * Display all posts.
     * COURSE: Eloquent - Reading data, eager loading
     */
    public function index()
    {
        $posts = Post::with(['category', 'user'])->latest()->paginate(10);
        return view('admin.posts.index', compact('posts'));
    }

    /**
     * Show create form.
     * COURSE: Views - passing data, Blade templating
     */
    public function create()
    {
        $categories = Category::all();
        $tags = Tag::all();
        return view('admin.posts.create', compact('categories', 'tags'));
    }

    /**
     * Store a new post.
     * COURSE: Form Validation, Eloquent insert, File Upload, Flash messages
     */
    public function store(Request $request)
    {
        // COURSE: Forms & Validation - validation rules
        $validated = $request->validate([
            'title'       => 'required|string|max:255',
            'excerpt'     => 'required|string|max:500',
            'body'        => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'is_published'=> 'nullable|boolean',
            'tags'        => 'nullable|array',
            'tags.*'      => 'exists:tags,id',
        ]);

        // COURSE: File Management - storing uploaded image
        $imagePath = null;
        if ($request->hasFile('image')) {
            // store() moves the file to storage/app/public/posts/
            $imagePath = $request->file('image')->store('posts', 'public');
        }

        // COURSE: Eloquent - Inserting data with create()
        $post = Post::create([
            'title'        => $validated['title'],
            'slug'         => Str::slug($validated['title']) . '-' . uniqid(),
            'excerpt'      => $validated['excerpt'],
            'body'         => $validated['body'],
            'category_id'  => $validated['category_id'],
            'user_id'      => auth()->id(),
            'image'        => $imagePath,
            'is_published' => $request->has('is_published'),
        ]);

        // COURSE: Eloquent Relationships - sync many-to-many (tags)
        if ($request->has('tags')) {
            $post->tags()->sync($request->tags);
        }

        // COURSE: Flash Messages
        return redirect()->route('admin.posts.index')
            ->with('success', 'Post created successfully!');
    }

    /**
     * Show edit form.
     * COURSE: Eloquent - Finding data by ID, passing to view
     */
    public function edit(Post $post)
    {
        $categories = Category::all();
        $tags = Tag::all();
        return view('admin.posts.edit', compact('post', 'categories', 'tags'));
    }

    /**
     * Update existing post.
     * COURSE: Eloquent - Updating data, File Management
     */
    public function update(Request $request, Post $post)
    {
        $validated = $request->validate([
            'title'       => 'required|string|max:255',
            'excerpt'     => 'required|string|max:500',
            'body'        => 'required|string',
            'category_id' => 'required|exists:categories,id',
            'image'       => 'nullable|image|mimes:jpg,jpeg,png,webp|max:2048',
            'is_published'=> 'nullable|boolean',
            'tags'        => 'nullable|array',
            'tags.*'      => 'exists:tags,id',
        ]);

        // Handle image replacement
        if ($request->hasFile('image')) {
            // Delete old image from storage
            if ($post->image) {
                \Storage::disk('public')->delete($post->image);
            }
            $validated['image'] = $request->file('image')->store('posts', 'public');
        }

        // COURSE: Eloquent - Updating data with update()
        $post->update([
            'title'        => $validated['title'],
            'slug'         => Str::slug($validated['title']) . '-' . $post->id,
            'excerpt'      => $validated['excerpt'],
            'body'         => $validated['body'],
            'category_id'  => $validated['category_id'],
            'image'        => $validated['image'] ?? $post->image,
            'is_published' => $request->has('is_published'),
        ]);

        // Sync tags (many-to-many)
        $post->tags()->sync($request->tags ?? []);

        return redirect()->route('admin.posts.index')
            ->with('success', 'Post updated successfully!');
    }

    /**
     * Delete a post.
     * COURSE: Eloquent - Deleting data with delete()
     */
    public function destroy(Post $post)
    {
        // Delete image from storage
        if ($post->image) {
            \Storage::disk('public')->delete($post->image);
        }

        // Detach tags (pivot table cleanup)
        $post->tags()->detach();

        // COURSE: Eloquent - Deleting data
        $post->delete();

        return redirect()->route('admin.posts.index')
            ->with('success', 'Post deleted successfully!');
    }

    /**
     * Standalone image upload endpoint.
     * COURSE: File Management - Storage facade
     */
    public function uploadImage(Request $request, Post $post)
    {
        $request->validate(['image' => 'required|image|max:2048']);

        $path = $request->file('image')->store('posts', 'public');
        $post->update(['image' => $path]);

        return back()->with('success', 'Image uploaded!');
    }
}
