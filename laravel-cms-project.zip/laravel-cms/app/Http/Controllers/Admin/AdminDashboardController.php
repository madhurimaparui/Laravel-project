<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Post;
use App\Models\Category;
use App\Models\User;
use App\Models\Comment;

/**
 * AdminDashboardController
 * COURSE: Eloquent - aggregate queries (count), passing data to views
 */
class AdminDashboardController extends Controller
{
    public function index()
    {
        $stats = [
            'posts'      => Post::count(),
            'published'  => Post::where('is_published', true)->count(),
            'categories' => Category::count(),
            'users'      => User::count(),
            'comments'   => Comment::count(),
        ];

        $recentPosts = Post::with('user')->latest()->limit(5)->get();

        return view('admin.dashboard', compact('stats', 'recentPosts'));
    }
}
