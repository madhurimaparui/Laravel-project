<?php

namespace App\Http\Controllers;

use App\Models\Category;
use Illuminate\Http\Request;

/**
 * CategoryController (Public)
 * COURSE: Controllers, Eloquent relationships
 */
class CategoryController extends Controller
{
    public function index()
    {
        $categories = Category::withCount('posts')->get();
        return view('categories.index', compact('categories'));
    }

    public function show($slug)
    {
        $category = Category::where('slug', $slug)->firstOrFail();
        $posts = $category->posts()->with(['user', 'tags'])->published()->paginate(6);
        return view('categories.show', compact('category', 'posts'));
    }
}
