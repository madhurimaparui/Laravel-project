<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Post Model
 *
 * COURSE SECTIONS COVERED:
 * - Laravel Fundamentals: Database – Eloquent / ORM
 * - Eloquent Relationships (hasOne, hasMany, belongsTo, belongsToMany)
 * - Eloquent CRUD (create, read, update, delete)
 * - Laravel Migrations (see database/migrations/create_posts_table.php)
 */
class Post extends Model
{
    use HasFactory;

    /**
     * Mass-assignable fields.
     * COURSE: Eloquent - Inserting data with create()
     */
    protected $fillable = [
        'title',
        'slug',
        'excerpt',
        'body',
        'image',
        'is_published',
        'user_id',
        'category_id',
    ];

    /**
     * Attribute casting.
     */
    protected $casts = [
        'is_published' => 'boolean',
    ];

    // ─── RELATIONSHIPS ─────────────────────────────────────────────────────────
    // COURSE: Eloquent Relationships section

    /**
     * A post belongs to one user (author).
     * COURSE: belongsTo relationship
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * A post belongs to one category.
     * COURSE: belongsTo relationship
     */
    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    /**
     * A post has many tags (many-to-many).
     * COURSE: belongsToMany relationship
     */
    public function tags()
    {
        return $this->belongsToMany(Tag::class);
    }

    /**
     * A post has many comments.
     * COURSE: hasMany relationship
     */
    public function comments()
    {
        return $this->hasMany(Comment::class);
    }

    // ─── SCOPES ────────────────────────────────────────────────────────────────
    // COURSE: More ways to retrieve data

    /** Return only published posts. */
    public function scopePublished($query)
    {
        return $query->where('is_published', true);
    }

    /** Return latest posts first. */
    public function scopeLatest($query)
    {
        return $query->orderBy('created_at', 'desc');
    }

    // ─── ACCESSORS ─────────────────────────────────────────────────────────────

    /** Return a default image if no image is set. */
    public function getImageUrlAttribute()
    {
        return $this->image
            ? asset('storage/' . $this->image)
            : asset('images/default-post.jpg');
    }
}
