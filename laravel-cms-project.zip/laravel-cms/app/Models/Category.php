<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Category Model
 * COURSE: Eloquent relationships – hasMany, belongsTo
 */
class Category extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'slug', 'description'];

    /**
     * A category has many posts.
     * COURSE: hasMany relationship
     */
    public function posts()
    {
        return $this->hasMany(Post::class);
    }
}
