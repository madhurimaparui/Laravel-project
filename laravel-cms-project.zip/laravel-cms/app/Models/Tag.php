<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

/**
 * Tag Model
 * COURSE: belongsToMany (many-to-many) relationship
 */
class Tag extends Model
{
    use HasFactory;

    protected $fillable = ['name', 'slug'];

    /**
     * A tag belongs to many posts.
     * COURSE: belongsToMany relationship
     */
    public function posts()
    {
        return $this->belongsToMany(Post::class);
    }
}
