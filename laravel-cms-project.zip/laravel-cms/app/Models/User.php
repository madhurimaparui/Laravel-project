<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

/**
 * User Model
 * COURSE: Authentication, Roles & Middleware
 */
class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    protected $fillable = [
        'name',
        'email',
        'password',
        'role',   // 'admin' or 'user'
    ];

    protected $hidden = [
        'password',
        'remember_token',
    ];

    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    /**
     * Check if user is admin.
     * COURSE: Middleware & Roles
     */
    public function isAdmin()
    {
        return $this->role === 'admin';
    }

    /**
     * A user has many posts.
     * COURSE: hasMany relationship
     */
    public function posts()
    {
        return $this->hasMany(Post::class);
    }

    /**
     * A user has many comments.
     */
    public function comments()
    {
        return $this->hasMany(Comment::class);
    }
}
